#ifndef __CRIS_CPUTIME_H
#define __CRIS_CPUTIME_H

#include <asm-generic/cputime.h>

#endif /* __CRIS_CPUTIME_H */
