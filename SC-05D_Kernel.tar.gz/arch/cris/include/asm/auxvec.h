#ifndef __ASMCRIS_AUXVEC_H
#define __ASMCRIS_AUXVEC_H

#endif
