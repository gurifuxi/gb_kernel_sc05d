#ifndef _CRIS_SETUP_H
#define _CRIS_SETUP_H

#define COMMAND_LINE_SIZE	256

#endif
