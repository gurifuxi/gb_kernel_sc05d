#ifndef _CRIS_PERCPU_H
#define _CRIS_PERCPU_H

#include <asm-generic/percpu.h>

#endif /* _CRIS_PERCPU_H */
