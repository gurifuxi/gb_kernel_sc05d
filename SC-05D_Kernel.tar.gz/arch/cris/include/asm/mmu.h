/*
 * CRIS MMU constants and PTE layout
 */

#ifndef _CRIS_MMU_H
#define _CRIS_MMU_H

#include <arch/mmu.h>

#endif
