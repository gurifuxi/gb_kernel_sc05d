#ifndef _CRIS_SWAB_H
#define _CRIS_SWAB_H

#ifdef __KERNEL__
#include <arch/swab.h>
#endif /* __KERNEL__ */

#endif /* _CRIS_SWAB_H */
